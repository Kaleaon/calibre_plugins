"""Metabods parsing and download logic. Pure standard library so it can be tested outside Calibre."""

import copy
import functools
import html
import re
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import parse_qs, urlparse

try:  # inside Calibre the shared module ships in the plugin package
    from .storykit import (  # noqa: F401
        Cancelled,
        Fetcher,
        clean_fragment,
        decode,
        epub_builder,
        parse_chapter_range,
        strip_tags,
    )
    from .storykit import build_epub as _build_epub
except ImportError:  # tests load this file directly with common/ on sys.path
    from storykit import (  # noqa: F401
        Cancelled,
        Fetcher,
        clean_fragment,
        decode,
        epub_builder,
        parse_chapter_range,
        strip_tags,
    )
    from storykit import build_epub as _build_epub

SITE = "https://metabods.com/mbxy/site/"
PUBLISHER = "Metabods"

build_epub = functools.partial(_build_epub, publisher=PUBLISHER)


# ---------------------------------------------------------------- input parsing

SLUG = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_\-]*$")


def story_url(story_id):
    return f"{SITE}story.php?id={story_id}"


def print_url(story_id):
    return f"{SITE}story_print.php?id={story_id}"


def tag_url(tag_id):
    return f"{SITE}archive.php?list=tag&id={int(tag_id)}"


def classify(line):
    """Return ('story', id), ('list', url) or None for one line of user input."""
    line = line.strip()
    if not line:
        return None
    if "://" not in line and SLUG.match(line):
        return "story", line
    if "://" not in line and line.startswith(("metabods.com", "www.metabods.com")):
        line = "https://" + line
    parsed = urlparse(line)
    if not parsed.netloc.lower().endswith("metabods.com"):
        return None
    query = parse_qs(parsed.query)
    path = parsed.path.rsplit("/", 1)[-1]
    if (
        path in ("story.php", "story_print.php")
        and query.get("id")
        and SLUG.match(query["id"][0])
    ):
        return "story", query["id"][0]
    if path == "archive.php" and query.get("list"):
        return "list", f"{SITE}archive.php?" + parsed.query
    return None


# ---------------------------------------------------------------- list pages

_ROW = re.compile(
    r'<a\s[^>]*href="[^"]*story\.php\?id=([^"&]+)"[^>]*>(.*?)</a>(?:\s|<wbr>|&nbsp;)*'
    r"(?:by\s*<a\s[^>]*list=author&(?:amp;)?id=(\d+)[^>]*>(.*?)</a>)?",
    re.S | re.I,
)


def parse_story_rows(page):
    """Stories listed on an archive/author/tag/category page, in page order, de-duplicated."""
    rows = {}
    for m in _ROW.finditer(page):
        title = strip_tags(m.group(2))
        if not title:
            continue
        sid = html.unescape(m.group(1))
        author = strip_tags(m.group(4) or "")
        if sid not in rows:
            rows[sid] = {"id": sid, "title": title, "author": author}
        elif author and not rows[sid]["author"]:
            rows[sid]["author"] = author
    return list(rows.values())


def parse_tag_index(page):
    tags = {}
    for m in re.finditer(
        r'<a\s[^>]*href="[^"]*list=tag&(?:amp;)?id=(\d+)"[^>]*>(.*?)</a>', page, re.S
    ):
        name = strip_tags(m.group(2))
        if name and name.lower() != "all tags":
            tags.setdefault(int(m.group(1)), name)
    return sorted(tags.items(), key=lambda t: t[1].casefold())


def _report_progress(progress_cb, completed, total):
    if not progress_cb:
        return
    try:
        progress_cb(completed, total)
    except TypeError:
        try:
            progress_cb(f"Reading tag {completed} of {total}…")
        except Exception:
            pass
    except Exception:
        pass


def make_thread_fetcher(fetcher=None):
    if fetcher is None:
        return Fetcher()
    try:
        tf = copy.copy(fetcher)
        tf._lock = threading.Lock()
        tf._last = 0.0
        return tf
    except Exception:
        kwargs = {}
        for attr in ('min_interval', 'cancelled', 'opener'):
            val = getattr(fetcher, attr, None)
            if val is not None:
                kwargs[attr] = val
        return Fetcher(**kwargs)


_make_thread_fetcher = make_thread_fetcher


def search_tags(fetcher, tag_ids, progress=None, max_workers=5):
    """Stories carrying each tag; returns {tag_id: [rows]}."""
    tag_ids = list(dict.fromkeys(tag_ids))
    if not tag_ids:
        return {}

    def is_cancelled():
        if hasattr(fetcher, "cancelled") and callable(fetcher.cancelled):
            return fetcher.cancelled()
        return False

    if is_cancelled():
        raise Cancelled()

    def make_thread_fetcher():
        try:
            tf = copy.copy(fetcher)
            tf._lock = threading.Lock()
            tf._last = 0.0
            return tf
        except Exception:
            kwargs = {}
            for attr in ('min_interval', 'cancelled', 'opener'):
                val = getattr(fetcher, attr, None)
                if val is not None:
                    kwargs[attr] = val
            return Fetcher(**kwargs)

    results = {}
    completed_count = 0
    lock = threading.Lock()

    def fetch_one(tid):
        nonlocal completed_count
        if is_cancelled():
            raise Cancelled()
        t_fetcher = make_thread_fetcher()
        page = t_fetcher.get(tag_url(tid))
        rows = parse_story_rows(page)
        with lock:
            completed_count += 1
            _report_progress(progress, completed_count, len(tag_ids))
        return tid, rows

    pool_size = min(max_workers, len(tag_ids)) if max_workers > 0 else 1
    with ThreadPoolExecutor(max_workers=pool_size) as executor:
        futures = {executor.submit(fetch_one, tid): tid for tid in tag_ids}
        try:
            for future in as_completed(futures):
                if is_cancelled():
                    for f in futures:
                        f.cancel()
                    raise Cancelled()
                tid, rows = future.result()
                results[tid] = rows
        except Cancelled:
            for f in futures:
                f.cancel()
            raise
        except Exception:
            for f in futures:
                f.cancel()
            raise

    return results


def combine_tag_results(results, match_all):
    """Union or intersection of per-tag story lists, ordered by title."""
    sets = [{r["id"] for r in rows} for rows in results.values()]
    if not sets:
        return []
    keep = set.intersection(*sets) if match_all else set.union(*sets)
    merged = {}
    for rows in results.values():
        for r in rows:
            if r["id"] in keep:
                merged.setdefault(r["id"], r)
    return sorted(merged.values(), key=lambda r: r["title"].casefold())


# ---------------------------------------------------------------- story pages


def parse_story_page(page):
    """Metadata from the normal story page (the print page lacks tags and summary)."""
    info = {"tags": [], "categories": [], "summary": ""}
    m = re.search(r"<h5>by\s*<a[^>]*>(.*?)</a>", page, re.S)
    if m:
        info["author"] = strip_tags(m.group(1))
    m = re.search(r"<h5>.*?</h5>\s*<p[^>]*>(.*?)</p>", page, re.S)
    if m:
        text = strip_tags(m.group(1))
        info["summary"] = text
    # The page repeats tags in a per-part popup and a duplicate header; only the first block is the story's own.
    start = page.find("fa-tags me-2")
    if start >= 0:
        end = page.find("fa-tags me-2", start + 12)
        block = page[start : end if end > 0 else start + 60000]
        seen = set()
        for kind, key in (("tag", "tags"), ("category", "categories")):
            for m in re.finditer(
                rf'<a\s[^>]*href="/mbxy/site/archive\.php\?list={kind}&(?:amp;)?id=\d+"[^>]*>(.*?)</a>',
                block,
                re.S,
            ):
                name = strip_tags(m.group(1)).lstrip("\u2022").strip()
                if name and (kind, name) not in seen:
                    seen.add((kind, name))
                    info[key].append(name)
    return info


def parse_print_page(page, chapter_range=None):
    """Title, author and the ordered (heading, html) sections of story_print.php."""
    m = re.search(r"<h1[^>]*>(.*?)</h1>", page, re.S)
    if not m:
        raise ValueError("Print page has no story title")
    title = strip_tags(m.group(1))
    m = re.search(r"<strong>\s*by\s+(.*?)</strong>", page, re.S)
    author = strip_tags(m.group(1)) if m else "Unknown"
    m = re.search(r"story copyright\s*&copy;\s*by\s*(.*?)<br", page, re.S)
    copyright_holder = strip_tags(m.group(1)) if m else author
    sections = []
    for chunk in page.split('<div class="xyp_section">')[1:]:
        start = re.search(r"<div[^>]*xyp_section_cols[^>]*>", chunk)
        if not start:
            continue  # title block or footer
        h = re.search(r"<h3[^>]*>(.*?)</h3>", chunk[: start.start()], re.S)
        body = re.sub(r"</div>\s*</div>\s*$", "", chunk[start.end() :].rstrip())
        sections.append((strip_tags(h.group(1)) if h else "", body))
    if not sections:
        raise ValueError("Print page has no story text")
    if chapter_range is not None:
        total_sections = len(sections)
        if isinstance(chapter_range, str):
            indices = parse_chapter_range(chapter_range, total_sections)
        else:
            indices = set(chapter_range)
        sections = [sec for i, sec in enumerate(sections) if i in indices]
        if not sections:
            raise ValueError(
                f'No chapters match range "{chapter_range}" (story has {total_sections} chapter(s))'
            )
    return {
        "title": title,
        "author": author,
        "copyright": copyright_holder,
        "sections": sections,
    }


def fetch_story(fetcher, story_id, chapter_range=None):
    """Download one story (all parts) and merge print-page text with story-page metadata."""
    story = parse_print_page(
        fetcher.get(print_url(story_id)), chapter_range=chapter_range
    )
    story["id"] = story_id
    story["url"] = story_url(story_id)
    try:
        info = parse_story_page(fetcher.get(story["url"]))
    except Cancelled:
        raise
    except OSError:
        info = {"tags": [], "categories": [], "summary": ""}
    story.update(
        tags=info["tags"], categories=info["categories"], summary=info["summary"]
    )
    return story


def expand_targets(fetcher, lines, progress=lambda msg: None):
    """Resolve pasted story ids/URLs and list pages (author, tag, category, archive) into story rows."""
    rows, errors = {}, []
    for line in lines:
        kind = classify(line)
        if kind is None:
            if line.strip():
                errors.append(f"Not a Metabods story or list address: {line.strip()}")
            continue
        if kind[0] == "story":
            rows.setdefault(kind[1], {"id": kind[1], "title": kind[1], "author": ""})
            continue
        progress(f"Reading list {kind[1]}")
        try:
            found = parse_story_rows(fetcher.get(kind[1]))
        except OSError as exc:
            errors.append(str(exc))
            continue
        if not found:
            errors.append(f"No stories found at {kind[1]}")
        for row in found:
            rows.setdefault(row["id"], row)
    return list(rows.values()), errors
